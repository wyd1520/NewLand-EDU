const { nanoid } = require('nanoid')
module.exports = () => {
  return nanoid(7)
}

/**
 * functions to create ssh log of session
 */

exports.createLogFileName = (id) => {
  return `${id}.log`
}
